﻿using System;
using System.Threading.Channels;

/* 
 * 
*/

namespace hurik
{ 



    class Program
    {

        static void Main(string[] args)
        {
            Dictionary<string, int> keyValuePairs = new Dictionary<string, int>()
            {
                { "C#", 10 },
                { "C++", 12 },
                { "Разработка программных модулей",  6 },
                { "Андроид",  6 },
                { "История", 2}
            };
            foreach (var item in keyValuePairs)
            {
                Console.WriteLine(item);
            }
            var maxSubj = keyValuePairs.MaxBy(x => x.Value);
            Console.WriteLine(maxSubj.Key, maxSubj.Value);
        }
    }
}